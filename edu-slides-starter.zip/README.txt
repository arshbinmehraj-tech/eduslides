
EduSlides Starter Website
--------------------------

How to Use:
1. Upload this folder to GitHub Pages or Netlify.
2. Open index.html to see homepage.
3. Add your own PPTs in 'downloads' folder.
4. Edit index.html and categories to add more posts.
5. Share your website link with friends for traffic.

Monetization Ideas:
- Google AdSense once traffic builds.
- Paid PPT bundles (₹99–₹199).
- Affiliate links to Amazon books/stationery.
